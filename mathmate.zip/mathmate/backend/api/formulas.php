<?php
require_once "../config/cors.php";
require_once "../config/db.php";

$topicId = $_GET['topic_id'] ?? null;

if ($topicId) {
    $stmt = $pdo->prepare("SELECT formulas.*, topics.title AS topic_title FROM formulas JOIN topics ON formulas.topic_id = topics.id WHERE topic_id = ?");
    $stmt->execute([$topicId]);
} else {
    $stmt = $pdo->query("SELECT formulas.*, topics.title AS topic_title FROM formulas JOIN topics ON formulas.topic_id = topics.id ORDER BY topics.title");
}

echo json_encode(["success" => true, "formulas" => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
?>
