<?php
require_once "../config/cors.php";
require_once "../config/db.php";

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $pdo->query("SELECT * FROM topics ORDER BY id DESC");
    echo json_encode(["success" => true, "topics" => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $title = trim($data["title"] ?? "");
    $description = trim($data["description"] ?? "");

    if (!$title || !$description) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "Title and description are required"]);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO topics (title, description) VALUES (?, ?)");
    $stmt->execute([$title, $description]);
    echo json_encode(["success" => true, "message" => "Topic added successfully"]);
    exit;
}
?>
