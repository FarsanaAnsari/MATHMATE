<?php
require_once "../config/cors.php";
require_once "../config/db.php";

$studentId = $_GET['student_id'] ?? null;

if (!$studentId) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "student_id is required"]);
    exit;
}

$stmt = $pdo->prepare("SELECT results.*, topics.title AS topic_title FROM results JOIN topics ON results.topic_id = topics.id WHERE student_id = ? ORDER BY results.created_at DESC");
$stmt->execute([$studentId]);

echo json_encode(["success" => true, "results" => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
?>
