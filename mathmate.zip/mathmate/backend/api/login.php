<?php
require_once "../config/cors.php";
require_once "../config/db.php";

$data = json_decode(file_get_contents("php://input"), true);
$email = trim($data["email"] ?? "");
$password = $data["password"] ?? "";

if (!$email || !$password) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Email and password are required"]);
    exit;
}

$stmt = $pdo->prepare("SELECT id, name, email, password FROM students WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user["password"])) {
    unset($user["password"]);
    echo json_encode(["success" => true, "message" => "Login successful", "user" => $user]);
} else {
    http_response_code(401);
    echo json_encode(["success" => false, "message" => "Invalid login details"]);
}
?>
