<?php
require_once "../config/cors.php";
require_once "../config/db.php";

$topicId = $_GET['topic_id'] ?? null;

if (!$topicId) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "topic_id is required"]);
    exit;
}

$stmt = $pdo->prepare("SELECT id, topic_id, question, option_a, option_b, option_c, option_d FROM questions WHERE topic_id = ?");
$stmt->execute([$topicId]);
echo json_encode(["success" => true, "questions" => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
?>
