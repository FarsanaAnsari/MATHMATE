<?php
require_once "../config/cors.php";
require_once "../config/db.php";

$data = json_decode(file_get_contents("php://input"), true);
$studentId = $data["student_id"] ?? null;
$topicId = $data["topic_id"] ?? null;
$answers = $data["answers"] ?? [];

if (!$studentId || !$topicId || !is_array($answers)) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Invalid quiz submission"]);
    exit;
}

$stmt = $pdo->prepare("SELECT id, correct_answer FROM questions WHERE topic_id = ?");
$stmt->execute([$topicId]);
$questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

$score = 0;
foreach ($questions as $question) {
    $questionId = $question['id'];
    if (isset($answers[$questionId]) && strtoupper($answers[$questionId]) === $question['correct_answer']) {
        $score++;
    }
}

$totalQuestions = count($questions);
$save = $pdo->prepare("INSERT INTO results (student_id, topic_id, score, total_questions) VALUES (?, ?, ?, ?)");
$save->execute([$studentId, $topicId, $score, $totalQuestions]);

echo json_encode([
    "success" => true,
    "message" => "Quiz submitted successfully",
    "score" => $score,
    "total_questions" => $totalQuestions
]);
?>
