<?php
echo json_encode([
    "app" => "MATHMATE API",
    "status" => "running",
    "endpoints" => [
        "/api/register.php",
        "/api/login.php",
        "/api/topics.php",
        "/api/formulas.php",
        "/api/questions.php?topic_id=1",
        "/api/submit_quiz.php",
        "/api/results.php?student_id=1"
    ]
]);
?>
