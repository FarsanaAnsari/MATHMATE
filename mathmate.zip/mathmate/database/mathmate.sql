CREATE DATABASE IF NOT EXISTS mathmate;
USE mathmate;

DROP TABLE IF EXISTS results;
DROP TABLE IF EXISTS questions;
DROP TABLE IF EXISTS formulas;
DROP TABLE IF EXISTS topics;
DROP TABLE IF EXISTS students;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE topics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL
);

CREATE TABLE formulas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    topic_id INT NOT NULL,
    title VARCHAR(150) NOT NULL,
    formula VARCHAR(255) NOT NULL,
    FOREIGN KEY (topic_id) REFERENCES topics(id) ON DELETE CASCADE
);

CREATE TABLE questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    topic_id INT NOT NULL,
    question TEXT NOT NULL,
    option_a VARCHAR(255) NOT NULL,
    option_b VARCHAR(255) NOT NULL,
    option_c VARCHAR(255) NOT NULL,
    option_d VARCHAR(255) NOT NULL,
    correct_answer CHAR(1) NOT NULL,
    FOREIGN KEY (topic_id) REFERENCES topics(id) ON DELETE CASCADE
);

CREATE TABLE results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    topic_id INT NOT NULL,
    score INT NOT NULL,
    total_questions INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (topic_id) REFERENCES topics(id) ON DELETE CASCADE
);

INSERT INTO topics (title, description) VALUES
('Algebra', 'Learn equations, variables, expressions, and simplification.'),
('Geometry', 'Study shapes, angles, area, perimeter, and volume.'),
('Trigonometry', 'Understand sine, cosine, tangent, and triangle relationships.'),
('Statistics', 'Learn mean, median, mode, range, and data interpretation.');

INSERT INTO formulas (topic_id, title, formula) VALUES
(1, 'Quadratic Formula', 'x = (-b ± √(b² - 4ac)) / 2a'),
(1, 'Difference of Squares', 'a² - b² = (a - b)(a + b)'),
(2, 'Area of Circle', 'A = πr²'),
(2, 'Pythagorean Theorem', 'a² + b² = c²'),
(3, 'Sine Ratio', 'sin θ = opposite / hypotenuse'),
(3, 'Cosine Ratio', 'cos θ = adjacent / hypotenuse'),
(4, 'Mean', 'Mean = Sum of values / Number of values'),
(4, 'Range', 'Range = Highest value - Lowest value');

INSERT INTO questions (topic_id, question, option_a, option_b, option_c, option_d, correct_answer) VALUES
(1, 'Simplify: 2x + 3x', '5x', '6x', 'x', '5', 'A'),
(1, 'Solve: x + 4 = 10', '4', '5', '6', '10', 'C'),
(2, 'How many degrees are in a triangle?', '90', '120', '180', '360', 'C'),
(2, 'Area of a circle is calculated using:', 'πr²', '2πr', 'l × b', 'a²', 'A'),
(3, 'sin θ equals:', 'adjacent/hypotenuse', 'opposite/hypotenuse', 'opposite/adjacent', 'hypotenuse/opposite', 'B'),
(3, 'tan θ equals:', 'opposite/adjacent', 'adjacent/opposite', 'opposite/hypotenuse', 'adjacent/hypotenuse', 'A'),
(4, 'Find the mean of 2, 4, 6.', '3', '4', '5', '6', 'B'),
(4, 'Find the range of 3, 8, 10.', '3', '5', '7', '10', 'C');
