import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { apiRequest } from '../services/api.js';

export default function Quiz() {
  const { topicId } = useParams();
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const user = JSON.parse(localStorage.getItem('mathmate_user'));

  useEffect(() => {
    apiRequest(`/questions.php?topic_id=${topicId}`)
      .then(data => setQuestions(data.questions))
      .catch(error => setError(error.message));
  }, [topicId]);

  function choose(questionId, option) {
    setAnswers({ ...answers, [questionId]: option });
  }

  async function submitQuiz() {
    try {
      const data = await apiRequest('/submit_quiz.php', {
        method: 'POST',
        body: JSON.stringify({
          student_id: user.id,
          topic_id: Number(topicId),
          answers
        })
      });
      setResult(data);
    } catch (error) {
      setError(error.message);
    }
  }

  if (result) {
    return (
      <section className="result-box">
        <h1>Quiz Completed</h1>
        <p>Your score: <strong>{result.score}</strong> / {result.total_questions}</p>
        <Link className="primary" to="/results">View Result History</Link>
      </section>
    );
  }

  return (
    <section>
      <h1>Quiz</h1>
      {error && <p className="error">{error}</p>}
      {questions.map((question, index) => (
        <article className="question-card" key={question.id}>
          <h3>{index + 1}. {question.question}</h3>
          {['A', 'B', 'C', 'D'].map(option => (
            <label className="option" key={option}>
              <input
                type="radio"
                name={`question-${question.id}`}
                checked={answers[question.id] === option}
                onChange={() => choose(question.id, option)}
              />
              {option}. {question[`option_${option.toLowerCase()}`]}
            </label>
          ))}
        </article>
      ))}
      {questions.length > 0 && <button className="primary" onClick={submitQuiz}>Submit Quiz</button>}
    </section>
  );
}
