import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { apiRequest } from '../services/api.js';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  function updateField(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  async function submit(event) {
    event.preventDefault();
    setMessage('');

    try {
      const data = await apiRequest('/login.php', {
        method: 'POST',
        body: JSON.stringify(form)
      });
      localStorage.setItem('mathmate_user', JSON.stringify(data.user));
      navigate('/dashboard');
    } catch (error) {
      setMessage(error.message);
    }
  }

  return (
    <div className="auth-card">
      <h2>Student Login</h2>
      <form onSubmit={submit}>
        <input name="email" type="email" placeholder="Email" value={form.email} onChange={updateField} />
        <input name="password" type="password" placeholder="Password" value={form.password} onChange={updateField} />
        <button type="submit">Login</button>
      </form>
      {message && <p className="error">{message}</p>}
      <p>New student? <Link to="/register">Register</Link></p>
    </div>
  );
}
