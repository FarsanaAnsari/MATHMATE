import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <section className="hero">
      <h1>Welcome to MATHMATE</h1>
      <p>A web application that helps students learn formulas, practice quizzes, and track mathematics progress.</p>
      <div className="actions">
        <Link className="primary" to="/register">Get Started</Link>
        <Link className="secondary" to="/login">Login</Link>
      </div>
    </section>
  );
}
