import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { apiRequest } from '../services/api.js';

export default function Register() {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  function updateField(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  async function submit(event) {
    event.preventDefault();
    setMessage('');

    try {
      await apiRequest('/register.php', {
        method: 'POST',
        body: JSON.stringify(form)
      });
      navigate('/login');
    } catch (error) {
      setMessage(error.message);
    }
  }

  return (
    <div className="auth-card">
      <h2>Create Account</h2>
      <form onSubmit={submit}>
        <input name="name" placeholder="Full name" value={form.name} onChange={updateField} />
        <input name="email" type="email" placeholder="Email" value={form.email} onChange={updateField} />
        <input name="password" type="password" placeholder="Password" value={form.password} onChange={updateField} />
        <button type="submit">Register</button>
      </form>
      {message && <p className="error">{message}</p>}
      <p>Already have an account? <Link to="/login">Login</Link></p>
    </div>
  );
}
