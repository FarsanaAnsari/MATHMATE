import { useEffect, useState } from 'react';
import { apiRequest } from '../services/api.js';

export default function Results() {
  const [results, setResults] = useState([]);
  const user = JSON.parse(localStorage.getItem('mathmate_user'));

  useEffect(() => {
    apiRequest(`/results.php?student_id=${user.id}`)
      .then(data => setResults(data.results));
  }, [user.id]);

  return (
    <section>
      <h1>Result History</h1>
      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Topic</th>
              <th>Score</th>
              <th>Total</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {results.map(result => (
              <tr key={result.id}>
                <td>{result.topic_title}</td>
                <td>{result.score}</td>
                <td>{result.total_questions}</td>
                <td>{new Date(result.created_at).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
