import { useEffect, useState } from 'react';
import { apiRequest } from '../services/api.js';

export default function Formulas() {
  const [formulas, setFormulas] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    apiRequest('/formulas.php').then(data => setFormulas(data.formulas));
  }, []);

  const filtered = formulas.filter(item =>
    `${item.topic_title} ${item.title} ${item.formula}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <section>
      <h1>Formula Library</h1>
      <input className="search" placeholder="Search formulas..." value={search} onChange={e => setSearch(e.target.value)} />
      <div className="grid">
        {filtered.map(item => (
          <article className="card" key={item.id}>
            <span className="badge">{item.topic_title}</span>
            <h3>{item.title}</h3>
            <p className="formula">{item.formula}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
