import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiRequest } from '../services/api.js';

export default function Dashboard() {
  const [topics, setTopics] = useState([]);
  const [error, setError] = useState('');
  const user = JSON.parse(localStorage.getItem('mathmate_user'));

  useEffect(() => {
    apiRequest('/topics.php')
      .then(data => setTopics(data.topics))
      .catch(error => setError(error.message));
  }, []);

  return (
    <section>
      <h1>Hello, {user.name}</h1>
      <p className="muted">Choose a mathematics topic and start practicing.</p>
      {error && <p className="error">{error}</p>}
      <div className="grid">
        {topics.map(topic => (
          <article className="card" key={topic.id}>
            <h3>{topic.title}</h3>
            <p>{topic.description}</p>
            <Link className="primary small" to={`/quiz/${topic.id}`}>Start Quiz</Link>
          </article>
        ))}
      </div>
    </section>
  );
}
