import { Link, useNavigate } from 'react-router-dom';

export default function Navbar() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('mathmate_user') || 'null');

  function logout() {
    localStorage.removeItem('mathmate_user');
    navigate('/login');
  }

  return (
    <nav className="navbar">
      <Link className="brand" to="/">MATHMATE</Link>
      <div className="nav-links">
        {user ? (
          <>
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/formulas">Formulas</Link>
            <Link to="/results">Results</Link>
            <button onClick={logout}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}
