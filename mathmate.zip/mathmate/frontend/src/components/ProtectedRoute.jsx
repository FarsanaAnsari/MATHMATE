import { Navigate } from 'react-router-dom';

export default function ProtectedRoute({ children }) {
  const user = localStorage.getItem('mathmate_user');
  return user ? children : <Navigate to="/login" />;
}
