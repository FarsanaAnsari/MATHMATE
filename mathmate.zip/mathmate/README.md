# MATHMATE - A Web Application for Students

MATHMATE is a student-focused mathematics learning web application built with:

- Frontend: React
- Backend: PHP REST API
- Database: MySQL

## Features

- Student registration and login
- Topic-wise math learning dashboard
- Formula reference section
- Quiz system with automatic scoring
- Result history
- Simple admin endpoints for topics and questions

## Folder Structure

```text
mathmate/
├── frontend/       React application
├── backend/        PHP REST API
└── database/       MySQL schema and seed data
```

## Requirements

- Node.js 18+
- PHP 8+
- MySQL / MariaDB
- Apache, XAMPP, WAMP, Laragon, or PHP built-in server

## Database Setup

1. Open phpMyAdmin or MySQL CLI.
2. Import:

```text
database/mathmate.sql
```

3. Update database credentials in:

```text
backend/config/db.php
```

Default credentials:

```php
$host = "localhost";
$dbname = "mathmate";
$username = "root";
$password = "";
```

## Backend Setup

From the `backend` folder, run:

```bash
php -S localhost:8000
```

Backend API base URL:

```text
http://localhost:8000/api
```

## Frontend Setup

From the `frontend` folder, run:

```bash
npm install
npm run dev
```

Frontend URL:

```text
http://localhost:5173
```

## Demo Login

After importing the SQL file, create a student using the Register page, then login with that account.

## Important Notes

This is a beginner-friendly academic project. For production use, add stronger authentication, HTTPS, advanced validation, rate limiting, and role-based authorization.
